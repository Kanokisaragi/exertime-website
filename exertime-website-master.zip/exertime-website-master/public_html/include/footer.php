<footer>
    <div class="footer-content">
        <p><img src="./resources/img/logo.jpg" alt="Exertime Logo">
             | Copyright 2012 by Scott Pederson and Dean Cooley</p>

        <ul>
            <li><a href="#">Logout</a></li>
            <li> | </li>
            <li><a href="#">Privacy Policy</a></li>
        </ul>
    </div>
</footer>
