<div id="modal" class="modal-bg">
    <div class="modal-content">
        <button id="btn-close" class="close" type="button" name="">X</button>
        <h2>Title</h2>
    </div>
</div>
